//
//  ProtocolUploadImage.swift
//  Test_Final
//
//  Created by Octopus John on 4/22/23.
//

import Foundation
import UIKit

protocol UploadImageProtocol{
    func uploadImageDelegate(img : UIImage, locationImage : String, titleImage : String)
}
