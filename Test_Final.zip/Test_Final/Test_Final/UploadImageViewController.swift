//
//  UploadImageViewController.swift
//  Test_Final
//
//  Created by Octopus John on 4/21/23.
//

import UIKit
import CoreLocation

class UploadImageViewController: UIViewController, CLLocationManagerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var uploadProtocol : UploadImageProtocol?

    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var imgView: UIImageView!
    
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        // Do any additional setup after loading the view.
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage{
            imgView.image = image
        }
        picker.dismiss(animated: true)
    }
    
    @IBAction func takeAPicAction(_ sender: Any) {
        let actionSheet = UIAlertController(title: "Take a Picture", message: "Choose your photo", preferredStyle: .alert)
        
        let cameraAction = UIAlertAction(title: "Camera", style: .default){action in
            if UIImagePickerController.isSourceTypeAvailable(.camera){
                let imgPicker = UIImagePickerController()
                imgPicker.delegate = self
                imgPicker.sourceType = UIImagePickerController.SourceType.camera
                imgPicker.allowsEditing = false
                self.present(imgPicker, animated: true)
            }
}
        
        let photoLibraryAction = UIAlertAction(title: "Photo Library", style: .default){action in
            if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
                let imgPicker = UIImagePickerController()
                imgPicker.delegate = self
                imgPicker.sourceType = UIImagePickerController.SourceType.photoLibrary
                imgPicker.allowsEditing = false
                self.present(imgPicker, animated: true)
            }

        }
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel)
        
        actionSheet.addAction(cameraAction)
        actionSheet.addAction(photoLibraryAction)
        actionSheet.addAction(cancel)
        
        self.present(actionSheet, animated: true)
    }
    

    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else {return}
        getAddressFromLocation(location: location)
    }
    
    func getAddressFromLocation(location: CLLocation){
        let geoCoder = CLGeocoder()
        geoCoder.reverseGeocodeLocation(location) { placemarks, error in
            if error != nil{
                print(error)
                return
            }
            
            var address = ""
            guard let place = placemarks?.first else {return}
            if place.name != nil{
                address += place.name!
            }
            self.lblLocation.text = address
//            print(address)
            
            
            guard let img = self.imgView.image else {return}
            guard let location = self.lblLocation.text else {return}
            guard let title = self.txtTitle.text else {return}
    //        print(location)
            self.uploadProtocol?.uploadImageDelegate(img: img, locationImage: location, titleImage: title)
            print(self.lblLocation.text)
        }
    }
    
    @IBAction func uploadAction(_ sender: Any) {
        locationManager.requestLocation()
        self.tabBarController?.selectedIndex = 0
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
