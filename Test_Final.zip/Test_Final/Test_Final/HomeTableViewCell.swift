//
//  HomeTableViewCell.swift
//  Test_Final
//
//  Created by Octopus John on 4/22/23.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var imageContainer: UIImageView!
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var lblLocation: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
