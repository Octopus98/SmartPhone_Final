//
//  HomeViewController.swift
//  Test_Final
//
//  Created by Octopus John on 4/21/23.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UploadImageProtocol {
    
    var images:[UIImage] = [UIImage]()
    var locations = [String]()
    var imageTitle = [String]()
    
    func uploadImageDelegate(img: UIImage, locationImage: String, titleImage : String) {
        images.append(img)
        print(locationImage)
        locations.append(locationImage)
        imageTitle.append(titleImage)
        
        tblView.reloadData()
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        imageTitle.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! HomeTableViewCell
        let cell = Bundle.main.loadNibNamed("HomeTableViewCell", owner: self)?.first as! HomeTableViewCell
        cell.lblTitle.text = imageTitle[indexPath.row]
        cell.imageContainer.image = images[indexPath.row]
        cell.lblLocation.text = locations[indexPath.row]
        return cell
    }
    
    
    @IBOutlet weak var tblView: UITableView!
    var uploadImageVC : UIViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let controller = navigationController?.tabBarController
        uploadImageVC = navigationController?.tabBarController?.viewControllers?[0]
        print(uploadImageVC?.title)
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
